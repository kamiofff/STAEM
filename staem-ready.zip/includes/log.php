
<?php
function log_auth($db,$uid,$action){
 $ip=$_SERVER['REMOTE_ADDR']??'';
 $ua=$_SERVER['HTTP_USER_AGENT']??'';
 $db->prepare("INSERT INTO auth_logs (user_id,action,ip,user_agent) VALUES (?,?,?,?)")
    ->execute([$uid,$action,$ip,$ua]);
}
