
<?php
function totp_generate_secret(){ return base64_encode(random_bytes(10)); }
