
<?php
require __DIR__."/../includes/db.php";
require __DIR__."/../includes/log.php";
session_start();
if($_SERVER['REQUEST_METHOD']==='POST'){
 $login=$_POST['login']??'';
 $pass=$_POST['password']??'';
 $s=$db->prepare("SELECT * FROM users WHERE login=?");
 $s->execute([$login]);
 $u=$s->fetch();
 if($u && password_verify($pass,$u['password_hash'])){
   $_SESSION['uid']=$u['id'];
   log_auth($db,$u['id'],'login');
   echo "Logged in";
 } else echo "Error";
}
?>
<form method="post">
<input name="login" placeholder="Login">
<input name="password" type="password" placeholder="Password">
<button>Login</button>
</form>
