
<?php
require __DIR__."/../includes/db.php";
require __DIR__."/../includes/log.php";
require __DIR__."/../includes/totp.php";
if($_SERVER['REQUEST_METHOD']==='POST'){
 $login=$_POST['login']??'';
 $pass=password_hash($_POST['password']??'',PASSWORD_ARGON2ID);
 $secret=totp_generate_secret();
 $db->prepare("INSERT INTO users(login,password_hash,totp_secret) VALUES(?,?,?)")
    ->execute([$login,$pass,$secret]);
 log_auth($db,$db->lastInsertId(),'register');
 echo "Registered";
}
?>
<form method="post">
<input name="login" placeholder="Login">
<input name="password" type="password" placeholder="Password">
<button>Register</button>
</form>
